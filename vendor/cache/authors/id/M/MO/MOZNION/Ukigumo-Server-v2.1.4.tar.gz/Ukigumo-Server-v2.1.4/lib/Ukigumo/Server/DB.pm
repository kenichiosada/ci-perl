package Ukigumo::Server::DB;
use strict;
use warnings;
use utf8;
use parent 'Teng';

1;
