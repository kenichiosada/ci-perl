
# NAME

Ukigumo::Common - Common things between Ukigumo::Client/Ukigumo::Server

# SYNOPSIS

    use Ukigumo::Common;

# DESCRIPTION

Ukigumo::Common is a dummy package. This distribution contains a common things for client/server.

# POLICY

This distribution should on perl 5.8.

# AUTHOR

Tokuhiro Matsuno <tokuhirom AAJKLFJEF@ GMAIL COM>

# SEE ALSO

[Ukigumo::Client](https://metacpan.org/pod/Ukigumo::Client)/[Ukigumo::Server](https://metacpan.org/pod/Ukigumo::Server)

# LICENSE

Copyright (C) Tokuhiro Matsuno

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.
